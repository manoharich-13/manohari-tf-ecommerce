import json
import boto3
import uuid
import decimal

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('payments-table')

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, decimal.Decimal):
            return float(obj)
        return super().default(obj)

# ---------------------------
# Helper: CORS headers
# ---------------------------
def response(status, body):
    return {
        "statusCode": status,
        "headers": {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Allow-Methods": "GET,POST,OPTIONS"
        },
        "body": json.dumps(body, cls=DecimalEncoder)
    }

def lambda_handler(event, context):

    method = event.get("httpMethod")

    # ---------------- CORS ----------------
    if method == "OPTIONS":
        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Methods": "GET,POST,OPTIONS"
            },
            "body": json.dumps({"message": "CORS OK"})
        }

    # ---------------- POST ----------------
    if method == "POST":

        body = json.loads(event.get("body", "{}"))

        payment_id = str(uuid.uuid4())
        user = body.get("user")
        amount = body.get("amount")

        table.put_item(
            Item={
                "payment_id": payment_id,
                "user": user,
                "amount": amount
            }
        )

        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "*",
                "Access-Control-Allow-Methods": "*",
                "Content-Type": "application/json"
            },
            "body": json.dumps({
                "message": "Payment successful",
                "payment_id": payment_id,
                "user": user,
                "amount": amount
            })
        }
        


    # ---------------- GET ----------------
    if method == "GET":

        response = table.scan()
        items = response.get("Items", [])

        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps({
                "payments": items
            }, cls=DecimalEncoder)
        }

    return {
        "statusCode": 400,
        "headers": {
            "Access-Control-Allow-Origin": "*"
        },
        "body": json.dumps({"message": "Unsupported method"})
    }